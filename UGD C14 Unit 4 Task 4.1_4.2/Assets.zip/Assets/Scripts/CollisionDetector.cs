using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CollisionDetector : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created


    public Color[] color;
    public GameObject UI;
    private bool isGameOver = false;
    private GameObject player;
    private float bounceBack = 2.0f;
    private int enemyDestroyed = 0;

    public TextMeshProUGUI winState;
    public TextMeshProUGUI loseState;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (isGameOver && Input.GetKeyDown(KeyCode.R))
        {
            RestartGame();
        }
    }

    public void ChangePlayerColor(GameObject killer) 
    {
        int index = Random.Range(0, color.Length);

        Renderer renderer = killer.GetComponent<Renderer>();
        renderer.material.color = color[index];
    }

    public void ChangePlayerSize(GameObject killer) 
    {
        float sizeX = killer.transform.localScale.x;
        float sizeY = killer.transform.localScale.y;
        float sizeZ = killer.transform.localScale.z;
        float increaseSize = 0.05f;
        float maxSize = 10.0f;

        if (sizeX <= maxSize && sizeY <= maxSize && sizeZ <= maxSize)
        {
            killer.transform.localScale = new Vector3((sizeX + increaseSize), (sizeY + increaseSize), (sizeZ + increaseSize));
        }
    }

    public void EnemyFell(GameObject enemy)
    {
        Destroy(enemy);
        enemyDestroyed++;

        if (enemyDestroyed == 5)
        {
            isGameOver = true;
            UI.SetActive(true);
            winState.gameObject.SetActive(true);

            Time.timeScale = 0.0f;
        }
    }

    public void PlayerFell(GameObject killer)
    {
        player = killer;

        isGameOver = true;
        UI.SetActive(true);
        loseState.gameObject.SetActive(true);

        killer.SetActive(false);

        Time.timeScale = 0.0f;
    }

    void RestartGame()
    {
        Time.timeScale = 1.0f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }

    public void hitForce(GameObject enemy , GameObject killer)
    {
        Rigidbody killerRB = killer.GetComponent<Rigidbody>();
        Rigidbody enemyRB = enemy.GetComponent<Rigidbody>();

        float PosX = enemy.transform.position.x - killer.transform.position.y;
        float PosY = enemy.transform.position.y - killer.transform.position.y;
        float PosZ = enemy.transform.position.z - killer.transform.position.z;

        Vector3 afterHitPos = new Vector3(PosX,PosY,PosZ).normalized;

        enemyRB.AddForce(afterHitPos * bounceBack, ForceMode.Impulse);
        killerRB.AddForce(-afterHitPos * bounceBack, ForceMode.Impulse);
    }
}
