using UnityEngine;

public class CollisionDetector : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created 


    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        Rigidbody2D playerRB = collision.gameObject.GetComponent<Rigidbody2D>(); //get rigidbody of knife instance that collided with target
        playerRB.constraints = RigidbodyConstraints2D.FreezeAll; //stop all movements of knife from its Rigidbody
        collision.transform.SetParent(transform); //set the collided knife as child of the target
    }
}
