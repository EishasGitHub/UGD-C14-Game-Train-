using System.Collections;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    private float speed = 300.0f;
    private float horizontalInput;
    private float verticalInput;
    private CollisionManager CD;
    private Rigidbody playerRB;

    void Start()
    {
        CD = Object.FindFirstObjectByType<CollisionManager>();
        playerRB = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        //Move player with keyboard WASD or Arrow Keys
        horizontalInput = Input.GetAxis("Horizontal");
        verticalInput = Input.GetAxis("Vertical");

        playerRB.AddForce(Vector3.forward * verticalInput * speed *  Time.deltaTime );
        playerRB.AddForce(Vector3.right *  horizontalInput * speed * Time.deltaTime);
        FollowMouse();
        OutOfBounds();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            CD.hitForce(gameObject,collision.gameObject);
        }

        if (collision.gameObject.CompareTag("Wall"))
        {
            gameObject.SetActive(false);
            CD.RestartGame();
        }
    }

    void OutOfBounds()
    {
        //Make the Player stay within bounds
        if (transform.position.z > 4.82)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, 4.82f);
        }

        if (transform.position.z < -4.82)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, -4.82f);
        }

        if (transform.position.x > 8.81)
        {
            transform.position = new Vector3(8.81f, transform.position.y, transform.position.z);
        }

        if (transform.position.z < -8.81)
        {
            transform.position = new Vector3(-8.81f, transform.position.y, transform.position.z);
        }
    }

    void FollowMouse()
    {
        //Follow Mouse Pointer in World Point
        Vector3 mousePos = Input.mousePosition;

        Vector3 worldMousePos = Camera.main.ScreenToWorldPoint(new Vector3(mousePos.x, mousePos.y, Camera.main.transform.position.y));

        Vector3 direction = (worldMousePos - transform.position).normalized;
        direction.y = 0;

        transform.forward = direction; // look to the mouse pointer direction

    }

}
