using System.Collections;
using UnityEngine;

public class PlayerSpawnManager : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    public GameObject knifePrefab;
    private Vector2 knifePosition = new Vector2(0, -3.52f);
    public PlayerController controller = null;
    private int totalSpawns = 15;
    public GameObject targetPrefab;
    private int hits = 0;

    void Start()
    {
        GameObject X = Instantiate(knifePrefab, knifePosition, knifePrefab.transform.rotation); //spawn the first Knife at start of game
        controller.availableKnife = X; //give reference of the created instance of Knife to PlayerController
        totalSpawns -= 1;
    }
    public void isThrown()
    {
        //Spawn knives after some delay
        StartCoroutine(spawnKnife());
        hits += 1;
    }
    // Update is called once per frame
    void Update()
    {
        //Destroy Target after 14 hits
        if (hits == 14)
        {
            Destroy(targetPrefab);
        }
    }

    IEnumerator spawnKnife()
    {
        if (totalSpawns>1)
        {
            yield return new WaitForSeconds(0.1f); //wait for some time before creating another instance
            GameObject X = Instantiate(knifePrefab, knifePosition, knifePrefab.transform.rotation); //instance of knife created
            controller.availableKnife = X; //give reference of created instance of Knife to PlayerController
            totalSpawns -= 1;
        }
    }
}
