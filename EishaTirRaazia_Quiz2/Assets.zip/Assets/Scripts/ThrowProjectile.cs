using System.Collections;
using UnityEditor.Experimental.GraphView;
using UnityEngine;
using UnityEngine.AI;

public class ThrowProjectile : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private float maxSize = 2.5f;
    private float throwSpeed = 10.0f;
    private float increaseSize = 0.05f;


    
    void Start()
    {
    }

    // Update is called once per frame
    void Update()
    {
        //throw attack in direction of face of target object
        transform.Translate(Vector3.right * throwSpeed * Time.deltaTime);

        //Increase size of attack for more area coverage
        if (transform.localScale.y<maxSize)
        {
            transform.localScale = new Vector3(transform.localScale.x, transform.localScale.y + increaseSize, transform.localScale.z);
        }

        else
        {
            //Destory attack object after reaching maximum size
            Destroy(gameObject);
        }
    }

}
