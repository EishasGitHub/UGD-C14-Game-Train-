using UnityEngine;

public class OutOfBoundsDestroy : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //Destroy Brick at bottom limit
        if (transform.position.y == 0.3f)
        {
            Destroy(gameObject);
        }
    }
}
