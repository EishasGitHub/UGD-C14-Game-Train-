using System.Collections;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    private int Speed = 10;
    private float horizontalInput;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //Player movement
        horizontalInput = Input.GetAxis("Horizontal");

        transform.Translate(Vector3.right * Speed * Time.deltaTime * horizontalInput);

        if (transform.position.x < -8.0f)
        {
            transform.position = new Vector3(-8.0f,transform.position.y,transform.position.z);
        }

        else if (transform.position.x > 8.0f)
        {
            transform.position = new Vector3(8.0f,transform.position.y,transform.position.z);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        StartCoroutine(SlowMo());
    }

    IEnumerator SlowMo()
    {
        //slow motion experience
        Time.timeScale = 0.2f;
        yield return new WaitForSeconds(1.0f);
        Time.timeScale = 1.0f;
    }
}