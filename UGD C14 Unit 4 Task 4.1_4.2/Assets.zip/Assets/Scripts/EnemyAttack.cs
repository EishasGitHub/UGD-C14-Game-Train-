using UnityEngine;

public class EnemyAttack : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created


    public float speed;
    private GameObject killer;
    private Rigidbody enemyRB;
    private float offset = 1.0f;
    private float offsetSpeed = 10.0f;

    private CollisionDetector CD;

    void Start()
    {
        killer = GameObject.Find("Killer");
        enemyRB = GetComponent<Rigidbody>();
        CD = Object.FindFirstObjectByType<CollisionDetector>();
    }

    // Update is called once per frame
    void Update()
    {
        Vector3 cameraPos = (killer.transform.position - transform.position).normalized;

        float posX = Random.Range(-offset,offset); 
        float posZ = Random.Range(-offset,offset);

        Vector3 randomMovement = new Vector3(posX,0,posZ).normalized * offsetSpeed;

        enemyRB.AddForce((cameraPos+randomMovement) * speed * Time.deltaTime, ForceMode.Impulse);

        OutOfBounds();
    }

    void OutOfBounds()
    {
        if (transform.position.y < -5)
        {
            CD.EnemyFell(gameObject);
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Player"))
        {
            CD.hitForce(gameObject, collision.gameObject);
        }
    }
}
