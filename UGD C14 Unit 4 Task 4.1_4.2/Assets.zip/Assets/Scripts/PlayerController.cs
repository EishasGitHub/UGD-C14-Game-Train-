using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    private float speed = 600.0f;
    private Rigidbody killerRB;

    public CollisionDetector CD;

    void Start()
    {
        killerRB = GetComponent<Rigidbody>();
    }

    // Update is called once per frame
    void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");

        killerRB.AddForce(Vector3.forward * speed * verticalInput * Time.deltaTime);
        killerRB.AddForce(Vector3.right *  speed * horizontalInput * Time.deltaTime);

        OutOfBounds();
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Enemy"))
        {
            CD.ChangePlayerSize(gameObject);
            CD.ChangePlayerColor(gameObject);

        }
    }

    void OutOfBounds()
    {
        if (transform.position.y < -5)
        {
            CD.PlayerFell(gameObject);
        }
    }
}
