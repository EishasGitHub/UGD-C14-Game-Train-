using UnityEngine;
using TMPro;
using Unity.VisualScripting;
using UnityEngine.SceneManagement;

public class Player : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    private float horizontalInput;
    private float verticalInput;
    private float speed = 5f;
    private bool isladder = false;
    public Animator animator;
    private Rigidbody2D rb;
    public TextMeshProUGUI lives;
    private int noOfLives = 3;
    private bool isClimbing = false;
    public GameObject start;
    public GameObject backgroundstart;
    public bool GameStarted = false;
    public GameObject lose;
    public GameObject win;

    void Start()
    {
        Time.timeScale = 0f;

        rb = GetComponent<Rigidbody2D>();

        lives.text = "Lives: " + noOfLives + "/3";
        start.SetActive(true);
        backgroundstart.SetActive(true);
    }

    // Update is called once per frame
    void Update()
    {
        horizontalInput = Input.GetAxis("Horizontal");
        verticalInput = Input.GetAxis("Vertical");

        transform.Translate(Vector2.right * horizontalInput * Time.deltaTime * speed);

        jump();
        OutOfBounds();

        if (isladder && Mathf.Abs(verticalInput) > 0f)
        {
            isClimbing = true;
        }

        if (!GameStarted)
        {
            if (Input.GetKeyDown(KeyCode.Return))
            {
                start.SetActive(false);
                backgroundstart.SetActive(false);
                GameStarted = true;

                Time.timeScale = 1f;
            }

            if (Input.GetKeyDown(KeyCode.Escape))
            {
                SceneManager.LoadScene(SceneManager.GetActiveScene().name);
            }
        }


    }

    private void FixedUpdate()
    {
        if (isClimbing)
        {
            Physics2D.IgnoreLayerCollision(0, 9, true);
            rb.gravityScale = 0f;
            transform.Translate(Vector2.up * verticalInput * speed * Time.deltaTime);
        }

        else
        {
            rb.gravityScale = 1f;
        }
    }

    void OutOfBounds()
    {
        if (transform.position.x < -8.5f)
        {
            transform.position = new Vector2(-8.5f,transform.position.y);
        }

        else if (transform.position.x > 8.5f)
        {
            transform.position = new Vector2(8.5f,transform.position.y);
        }
    }

    void jump()
    {
        if (Input.GetKeyDown(KeyCode.Space) && !isladder) 
        {
            rb.AddForce(Vector2.up * speed, ForceMode2D.Impulse);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ball"))
        { 

            noOfLives--;
            lives.text = "Lives: " + noOfLives + "/3";

            if (noOfLives == 0)
            {
                Time.timeScale = 0f;
                lose.SetActive(true);
                backgroundstart.SetActive(true);
                GameStarted = false;
            }

        }

        if (collision.gameObject.CompareTag("Goal"))
        {
            Time.timeScale = 0f;
            win.SetActive(true);
            backgroundstart.SetActive(true);
            GameStarted = false;

        }

    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.gameObject.CompareTag("Ladder"))
        {
            isladder = true;
        }
        
    }

    private void OnTriggerExit2D(Collider2D collision)
    {
        isladder = false;
        isClimbing = false;
        Physics2D.IgnoreLayerCollision(0, 9, false);
    }

}
