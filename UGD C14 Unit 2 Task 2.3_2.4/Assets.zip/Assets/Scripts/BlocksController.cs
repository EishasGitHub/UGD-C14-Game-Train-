using UnityEngine;
using UnityEngine.UIElements;

public class BlocksController : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    public GameObject bricksPrefab;
    private float startDelay = 2.0f;
    private float spawnInterval = 3.0f;
    private float minRange = -9.0f;
    private float maxRange = 9.0f;
    private int totalBlocks = 7;
    
    void Start()
    {
        InvokeRepeating("SpawnManager", startDelay, spawnInterval);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void SpawnManager()
    {   
        //Spawn Bricks
        int emptyBlock = Random.Range(0, 7);

        float blockWidth = (maxRange - minRange)/totalBlocks;

        for (int i=0; i<totalBlocks;i++) 
        { 
            if (i!=emptyBlock)
            {
                float SpawnPosX =  (minRange + (i*blockWidth) + (blockWidth/2));

                Vector3 spawnPos = new Vector3(SpawnPosX, transform.position.y, transform.position.z);

                Instantiate(bricksPrefab,spawnPos,bricksPrefab.transform.rotation);
            }
        }
    }
}
