using UnityEngine;
using UnityEngine.SceneManagement;

public class CollisionManager : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    public GameObject player;
    public GameObject enemy;

    private float bounceBack = 2.0f;
    
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void hitForce(GameObject player, GameObject enemy)
    {
        //Rebound Force applied when Player collides with Enemy
        Rigidbody playerRB = player.GetComponent<Rigidbody>();
        Rigidbody enemyRB = enemy.GetComponent<Rigidbody>();

        
        Vector3 afterHitPos = (player.transform.position - enemy.transform.position).normalized;

        playerRB.AddForce(afterHitPos * bounceBack, ForceMode.Impulse); 
        enemyRB.AddForce(-afterHitPos * bounceBack, ForceMode.Impulse);
    }

    public void RestartGame()
    {
        //Restart the Game Scene
        Time.timeScale = 1.0f;
        SceneManager.LoadScene(SceneManager.GetActiveScene().name); //Loads the current scene
    }
}
