using System.Collections;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    private float speed = 70.0f;
    public GameObject availableKnife;
    public PlayerSpawnManager psm;

    void Start()
    {

    }

    // Update is called once per frame
    void Update()
    { 
        //Throw Knife upwards if Spacebar is pressed
        if (Input.GetKeyDown(KeyCode.Space) && availableKnife != null)
        {
            availableKnife.GetComponent<Rigidbody2D>().AddForce(Vector2.up * speed, ForceMode2D.Impulse); //Impulse is used for instant forces applied
            availableKnife = null; //set Knife availability to null as the current knife is thrown
            psm.isThrown(); //call to function from Player Spawn Manager
        }
    }
}
