using UnityEngine;

public class Fireball : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    private float speed = 5f;

    private Rigidbody2D rb;

    private Player p;

    void Start()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.linearVelocity = Vector2.right * speed;
    }

    // Update is called once per frame
    void Update()
    {
        OutOfBounds(); 
    }

    void OutOfBounds()
    {
        if (transform.position.x < -8.5f)
        {
            transform.position = new Vector2(-8.5f, transform.position.y);
            rb.linearVelocity = Vector2.right * speed;
        }

        else if (transform.position.x > 8.5f)
        {
            transform.position = new Vector2(8.5f, transform.position.y);
            rb.linearVelocity = Vector2.left * speed;
        }
    }
}
