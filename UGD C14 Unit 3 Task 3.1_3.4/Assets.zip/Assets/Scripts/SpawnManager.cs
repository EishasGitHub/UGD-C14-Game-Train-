using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    public GameObject ballPrefab;
    private float startDelay = 2.0f;
    private float repeatRate = 5.0f;

    void Start()
    {
        InvokeRepeating("SpawnBall",startDelay,repeatRate);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void SpawnBall()
    {
        float PosX = Random.Range(-7.30f, 7.30f);
        Vector2 spawnPosition = new Vector2(PosX, 3.35f);
        Instantiate(ballPrefab,spawnPosition,ballPrefab.transform.rotation);
    }
}
