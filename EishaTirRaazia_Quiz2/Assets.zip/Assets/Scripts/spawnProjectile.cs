using UnityEngine;

public class spawnProjectile : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    public GameObject projectile;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            spawn();
        }
    }

    void spawn()
    {
        Instantiate(projectile, transform.position, transform.rotation);
    }
}
