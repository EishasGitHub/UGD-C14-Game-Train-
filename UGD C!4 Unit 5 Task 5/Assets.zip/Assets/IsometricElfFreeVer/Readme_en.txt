//-----------------------------------------------------------
//  Isometric Character Animation Tilemap Set Free Ver 1.0
//
//  �@Data name:�@�@ ELF_Fighter_Female
//-----------------------------------------------------------

This asset is character tilemap animation data in Isometric/RPG SLG.
32x32 character animation tilemapped, sample animation included as DEMO
After executing the DEMO scene, you can operate the sample animation with the key operations displayed on the screen.

Here is a sample DEMO animation:

�EDirection keys Move/stop up/down/left/right along the isometric map chip
�EZ:�@ normal attack
�EX:�@ throwing attack
�EC:�@ Bow and arrow attack
�EV:�@ Defense
�EB: �@Items used
�EN: �@attack
�EM:�@ Death due to accumulation of damage, etc.

png data in the Image folder

�E64_Fild ~ sample map chip

�Eelf_bow.png    : bow attack tile
�Eelf_damage.png : damage and death
�Eelf_item.png   : defense and item use
�Eelf_slash.png  : Sword Attack
�Eelf_throw.png  : throw attack
�Eelf_walk.png   : Stop and walk
�Eitem.png       : Various items

You can use this asset for personal and commercial purpose,
you can modify this object to your needs.
Credit is not required but would be appreciated

You can NOT redistribute or resell it.