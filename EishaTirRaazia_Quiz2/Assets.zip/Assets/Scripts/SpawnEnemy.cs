using UnityEngine;

public class SpawnEnemy : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    public GameObject enemy;
    public Vector3[] positions;
    private float startDelay = 1.0f;
    private float interval = 1.5f;
    int index = 0;

    void Start()
    {
        InvokeRepeating("EnemySpawn", startDelay, interval);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void EnemySpawn()
    {
        //Instantiate Enemies from four different Positions
        GameObject enemy1 = Instantiate(enemy, positions[0],enemy.transform.rotation);
        GameObject enemy2 = Instantiate(enemy, positions[1],enemy.transform.rotation);
        GameObject enemy3 = Instantiate(enemy, positions[2],enemy.transform.rotation);
        GameObject enemy4 = Instantiate(enemy, positions[3],enemy.transform.rotation);
    }
}
