using TMPro;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    public float speed;
    private GameObject killer;
    
    void Start()
    {
        killer = GameObject.Find("Killer");

    }

    // Update is called once per frame
    void LateUpdate()
    {
        Vector3 cameraPos = (killer.transform.position - transform.position).normalized;
        transform.Translate(cameraPos * speed * Time.deltaTime);
    }
}
