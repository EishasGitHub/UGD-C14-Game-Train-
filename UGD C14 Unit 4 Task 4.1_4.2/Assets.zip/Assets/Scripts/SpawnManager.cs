using UnityEngine;

public class SpawnManager : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    
    public GameObject[] enemyPrefab;
    
    void Start()
    {
        SpawnEnemy();
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void SpawnEnemy()
    {
        for (int i=0; i<5; i++)
        {
            int index = Random.Range(0,enemyPrefab.Length);

            float SpawnPosX = Random.Range(-8.0f, 8.0f);
            float SpawnPosZ = Random.Range(-10.0f, 10.0f);

            Vector3 SpawnPos = new Vector3(SpawnPosX, 0, SpawnPosZ);

            Instantiate(enemyPrefab[index], SpawnPos, enemyPrefab[index].transform.rotation);
        }
    }
}
