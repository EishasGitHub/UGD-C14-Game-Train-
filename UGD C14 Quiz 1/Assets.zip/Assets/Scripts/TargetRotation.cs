using UnityEngine;

public class TargetRotation : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    private float speed = 100.0f;
    
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        //Continuously rotate the target
        transform.Rotate(Vector3.forward * speed * Time.deltaTime);
    }
}
