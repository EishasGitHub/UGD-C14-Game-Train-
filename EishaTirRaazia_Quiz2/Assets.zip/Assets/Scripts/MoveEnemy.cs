using System;
using System.Collections;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.AI;

public class MoveEnemy : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created
    private GameObject player;
    public NavMeshAgent agent;
    private float bounceBack = 10.0f;
    private int playerScore = 1;

    void Start()
    {
        player = GameObject.Find("Player");
    }

    // Update is called once per frame
    void Update()
    {
        if (agent.enabled == true && agent.isOnNavMesh)
        {
            agent.SetDestination(player.transform.position);
        }

        OutOfBounds();
    }

    private void OnCollisionEnter(Collision collision)
    {
        //Destroy Enemy if collided with the walls
        if(collision.gameObject.CompareTag("Wall"))
        {
            Destroy(gameObject);
            AttackDamage();

        }

        if (collision.gameObject.CompareTag("Projectile"))
        {
            StartCoroutine(recover(gameObject,collision.gameObject));
        }
    }

    IEnumerator recover(GameObject enemy, GameObject collider)
    {
        if (agent != null)
        {
            agent.enabled = false; //disable agent so that physics can be applied without affecting navmesh
        }

        Rigidbody enemyRB = enemy.GetComponent<Rigidbody>(); //get Rigidbody of Enemy

        if (enemyRB != null)
        {
            //Bounce back after collision with attack object
            Vector3 hitDirection = (enemy.transform.position - collider.transform.position).normalized;
            enemyRB.AddForce(hitDirection * bounceBack, ForceMode.Impulse);
        }

        yield return new WaitForSeconds(0.5f); //wai for 0.5seconds

        if (agent != null && agent.isOnNavMesh)
        {
            agent.enabled = true; 
        }

    }
    public void AttackDamage()
    {
        playerScore *=25;
        print("Player Score: " + playerScore);
    }

    void OutOfBounds()
    {
        //Make the Enemy stay within bounds
        if (transform.position.x > 8.81)
        {
            transform.position = new Vector3(8.81f, transform.position.y, transform.position.z);
        }

        if (transform.position.z < -8.81)
        {
            transform.position = new Vector3(-8.81f, transform.position.y, transform.position.z);
        }

        if (transform.position.z > 4.82)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, 4.82f);
        }

        if (transform.position.z < -4.82)
        {
            transform.position = new Vector3(transform.position.x, transform.position.y, -4.82f);
        }
    }
}
