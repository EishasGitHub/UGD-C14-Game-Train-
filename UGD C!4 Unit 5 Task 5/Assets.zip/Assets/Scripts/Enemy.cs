using System.Collections;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class Enemy : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    public GameObject fireball;
    private float delayTime = 1;
    private float repeatRate = 2;
    private float offsetx = 1;
    private float offsety = -0.4f;
    public Animator animator;
    private bool isThrowing = false;
    private Player p;

    void Start()
    {
        InvokeRepeating("throwFireball", delayTime, repeatRate);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void throwFireball()
    {


        if (!isThrowing)
        {
            isThrowing = true;
            animator.SetBool("throwFlag", true);
            StartCoroutine(Wait());
        }


    }

    IEnumerator Wait()
    {
        yield return new WaitForSeconds(0.6f);
        Vector3 spawnPosition = transform.position + new Vector3(offsetx, offsety, 0);
        Instantiate(fireball, (spawnPosition), transform.rotation);
        isThrowing = false;
        animator.SetBool("throwFlag", false);
    }

}
