using System;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // Start is called once before the first execution of Update after the MonoBehaviour is created

    private float speed = 15.0f;
    private float horizontalInput;
    public GameObject bulletPrefab;
    private float bulletSpeed = 18.0f;

    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        horizontalInput = Input.GetAxis("Horizontal");
        transform.Translate(Vector2.right * speed * horizontalInput * Time.deltaTime);
        BulletThrow();
    }

    void BulletThrow()
    {
        if (Input.GetKeyDown(KeyCode.Space)) 
        {
            Instantiate(bulletPrefab,transform.position,bulletPrefab.transform.rotation);
        }

        if (transform.position.x < -7.8f)
        {
            transform.position = new Vector2(-7.8f,transform.position.y);
        }

        if (transform.position.x > 7.8)
        {
            transform.position = new Vector2(7.8f, transform.position.y);
        }
    }

    private void OnCollisionEnter2D(Collision2D collision)
    {
        if (!collision.gameObject.CompareTag("Bullet")) 
        {
            print("Game Over!");
        }
    }
}
